from distutils.core import setup

setup(
    name = 'livingrimoire',
    packages = ['livingrimoire'],
    version = '1',  # Ideally should be same as your GitHub release tag varsion
    description = 'AGI software design pattern',
    author = 'moti barski',
    author_email = '',
    url = 'https://github.com/yotamarker/LivinGrimoireCorePython',
    download_url = 'https://github.com/yotamarker/LivinGrimoireCorePython/archive/refs/tags/0.1.10.tar.gz',
    keywords = ['tag1', 'tag2'],
    classifiers = [],
)