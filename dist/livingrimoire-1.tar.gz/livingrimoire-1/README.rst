moti barski wrote this

I moti barski do not allow anyone and or anybody and or any organization to
receive monetary profit from this living grimoire unless approved in writing by me personally.
you can use this for research.

*********
*CREDITS*
*********

the living grimoire was created by Moti Barski

Translation of code from java to python : Marco Vavassori (Vavuz), Moti Barski
Translation of code from java to kotlin : Moti Barski